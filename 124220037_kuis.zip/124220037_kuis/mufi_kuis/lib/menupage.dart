import 'package:flutter/material.dart';
import 'dummy_data.dart'; 

class MenuPage extends StatelessWidget {
  // Inisiasi variabel
  final String username;
  MenuPage({Key? key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Halaman Home"),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Text("Selamat Pagi! $username", style: TextStyle(fontSize: 20)),
          SizedBox(height: 10),
          Text("Yuk buat perubahan positif bagi lingkungan sekarang.", style: TextStyle(fontSize: 16),),
          
          GestureDetector(
            onTap: () {
              // Navigate untuk menuju halaman order page
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => OrderPage()),
              );
            },
            child: Card(
              margin: EdgeInsets.all(10),
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Pelajari teknisnya lebih lanjut.",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 5),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 24),

          SizedBox(height: 20),
          Expanded(
            // List view untuk menampilkan dummy data
            child: ListView.builder(
              itemCount: scheduleList.length, 
              itemBuilder: (context, index) {
                final schedule = scheduleList[index];
                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    leading: Image.network(schedule.imageUrl),
                    title: Text(schedule.wasteBankName),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Area: ${schedule.coverageArea}'),
                        Text('Date: ${schedule.implementationDate}'),
                        Text('Time: ${schedule.startTime} - ${schedule.endTime}'),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class OrderPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(  // untuk scroll kebawah
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, 
            children: [
              // Import gambar
              Image.network(
                'https://drive.google.com/file/d/1On0lV6P3c2-7v5QcuxkDhwk28TG9rybe/view?usp=sharing',  
                width: 200,   
                height: 200,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 20), 
              Text(
                'Apa itu Bank Sampah Keliling?',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),  
              Text(
                'Bank sampah keliling adalah inisiatif yang bertujuan untuk meningkatkan partisipasi masyarakat dalam pengelolaan sampah dan pencegahan pencemaran lingkungan. Biasanya dilaksanakan oleh komunitas atau organisasi non-pemerintah, bank sampah keliling menggunakan kendaraan khusus untuk mengumpulkan sampah dari rumah ke rumah atau dari lokasi yang telah ditentukan.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 10),
              Text(
                'Setelah dikumpulkan, sampah tersebut dibersihkan, dipilah, dan diolah menjadi bahan daur ulang. Melalui bank sampah keliling, masyarakat diberikan kesempatan untuk berpartisipasi aktif dalam menjaga lingkungan sekaligus memperoleh insentif berupa hadiah atau uang sebagai imbalan dari sampah yang mereka berikan.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 10),
              Text(
                'Dengan demikian, bank sampah keliling memiliki peran penting dalam mengedukasi masyarakat tentang pentingnya pengelolaan sampah yang berkelanjutan dan membantu mengurangi jumlah sampah yang masuk ke tempat pembuangan akhir.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),  

              ElevatedButton(
                onPressed: () {
                  // Kembali ke halaman home
                  Navigator.pop(context);
                },
                child: Text('Halaman Home'),
                style: ButtonStyle(
                backgroundColor: WidgetStatePropertyAll(Colors.deepPurple),
                foregroundColor: WidgetStatePropertyAll(Colors.white),
              ),
              ),
              SizedBox(height: 20), 
            ],
          ),
        ),
      ),
    );
  }
}
