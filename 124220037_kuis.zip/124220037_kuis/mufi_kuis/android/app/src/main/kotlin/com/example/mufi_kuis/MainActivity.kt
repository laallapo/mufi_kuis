package com.example.mufi_kuis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
